# ORBITRA GS-01 Ground Station Telemetry Specification

This document details the telemetry protocol and serial interface between the **Ground-Station ESP32** and the **ORBITRA GS-01 Dashboard** running in Chrome via the Web Serial API.

---

## 1. System Architecture

```
[CubeSat Sensors]
DHT11 / BMP280 / MPU6050 / NEO-6M / Battery
       │
       ▼
[CubeSat ESP32]
       │
       ▼  ESP-NOW (2.4 GHz Low-Latency Wireless)
[Ground-Station ESP32]
       │
       ▼  USB Serial (115200 Baud, 8-N-1, Newline-Delimited JSON)
[ORBITRA GS-01 Dashboard] (Web Serial API in Chrome/Edge)
```

---

## 2. Serial Port Configuration

- **Baud Rate**: `115200`
- **Data Bits**: `8`
- **Stop Bits**: `1`
- **Parity**: `None`
- **Flow Control**: `None`
- **Framing**: Newline-delimited UTF-8 text (`\n` or `\r\n`). Each line **must** be a single, complete JSON object.

---

## 3. Minimal Telemetry Packet

The dashboard is 100% compatible with minimal packets. Missing fields will **not** be invented or filled with synthetic fake jitter.

```json
{"temperature_c":27.2,"humidity_pct":58,"pressure_hpa":1007.8}
```

---

## 4. Full Telemetry Packet JSON Schema

For missions reporting full IMU, GNSS, power, and radio statistics:

```json
{
  "packet_id": 1052,
  "temperature_c": 26.5,
  "humidity_pct": 54.0,
  "pressure_hpa": 1011.4,
  "altitude_m": 143.1,
  "alt_msl": 102.4,
  "accel_x": 0.03,
  "accel_y": -0.02,
  "accel_z": 9.81,
  "gyro_x": 0.12,
  "gyro_y": -0.05,
  "gyro_z": 0.01,
  "pitch": 1.4,
  "roll": -0.8,
  "yaw": 42.6,
  "lat": 26.7314,
  "lng": 83.4331,
  "sats": 8,
  "speed": 0.0,
  "voltage": 3.84,
  "soc": 84,
  "free_heap": 184,
  "cpu_temp": 41.8,
  "rssi": -64,
  "rtt": 12
}
```

---

## 5. Supported Field Key Mappings

The parser recognizes both canonical names and common aliases:

| Parameter | Primary Key | Supported Aliases | Units / Type |
| :--- | :--- | :--- | :--- |
| **Packet ID** | `packet_id` | `pkt_id`, `packetId`, `pkt`, `id` | Integer |
| **Temperature** | `temperature_c` | `temp_c`, `temperature`, `temp`, `t` | °C (float) |
| **Humidity** | `humidity_pct` | `humidity`, `hum_pct`, `hum`, `h` | % (float) |
| **Pressure** | `pressure_hpa` | `pressure`, `press_hpa`, `press`, `p` | hPa (float) |
| **Altitude AGL** | `altitude_m` | `alt_m`, `altitude`, `alt_agl`, `alt` | meters (float) |
| **Altitude MSL** | `alt_msl` | `altMsl`, `gps_alt` | meters (float) |
| **Acceleration X** | `accel_x` | `ax`, `accel.x` | m/s² (float) |
| **Acceleration Y** | `accel_y` | `ay`, `accel.y` | m/s² (float) |
| **Acceleration Z** | `accel_z` | `az`, `accel.z` | m/s² (float) |
| **Gyroscope X** | `gyro_x` | `gx`, `gyro.x` | °/s (float) |
| **Gyroscope Y** | `gyro_y` | `gy`, `gyro.y` | °/s (float) |
| **Gyroscope Z** | `gyro_z` | `gz`, `gyro.z` | °/s (float) |
| **Pitch** | `pitch` | `orientation.pitch` | degrees (float) |
| **Roll** | `roll` | `orientation.roll` | degrees (float) |
| **Yaw** | `yaw` | `orientation.yaw` | degrees (float) |
| **Latitude** | `lat` | `latitude`, `gnss.lat` | decimal degrees |
| **Longitude** | `lng` | `lon`, `longitude`, `gnss.lng` | decimal degrees |
| **Satellites** | `sats` | `satellites`, `gnss.sats` | integer |
| **Speed** | `speed` | `spd`, `gnss.speed` | km/h (float) |
| **Battery Voltage** | `voltage` | `v_bat`, `vbat`, `eps.voltage` | Volts (float) |
| **Battery State of Charge**| `soc` | `battery_pct`, `bat_pct`, `eps.soc` | % (0-100) |
| **Free Heap** | `free_heap` | `heap`, `eps.freeHeap` | KB (integer) |
| **CPU Core Temp** | `cpu_temp` | `cpuTemp`, `eps.cpuTemp` | °C (float) |
| **RF RSSI** | `rssi` | `link.rssi` | dBm (integer) |
| **Link RTT** | `rtt` | `link.rtt` | ms (integer) |

---

## 6. Sample Ground-Station ESP32 Firmware (Arduino C++)

Flash this sketch onto the ESP32 plugged into your laptop via USB:

```cpp
#include <esp_now.h>
#include <WiFi.h>

// Struct matching CubeSat ESP-NOW payload
typedef struct __attribute__((packed)) {
  uint32_t packet_id;
  float temperature_c;
  float humidity_pct;
  float pressure_hpa;
  float altitude_m;
  float accel_x, accel_y, accel_z;
  float gyro_x, gyro_y, gyro_z;
  float pitch, roll, yaw;
  float lat, lng;
  uint8_t sats;
  float voltage;
} TelemetryData;

TelemetryData rxData;

// Callback when ESP-NOW packet arrives from CubeSat
void OnDataRecv(const esp_now_recv_info_t *esp_now_info, const uint8_t *incomingData, int len) {
  if (len == sizeof(TelemetryData)) {
    memcpy(&rxData, incomingData, sizeof(TelemetryData));
    int rssi = esp_now_info->rx_ctrl->rssi;

    // Forward as newline-delimited JSON over USB Serial to Chrome
    Serial.printf("{\"packet_id\":%u,\"temperature_c\":%.2f,\"humidity_pct\":%.1f,\"pressure_hpa\":%.2f,\"altitude_m\":%.1f,\"accel_x\":%.2f,\"accel_y\":%.2f,\"accel_z\":%.2f,\"gyro_x\":%.2f,\"gyro_y\":%.2f,\"gyro_z\":%.2f,\"pitch\":%.2f,\"roll\":%.2f,\"yaw\":%.2f,\"lat\":%.5f,\"lng\":%.5f,\"sats\":%u,\"voltage\":%.2f,\"rssi\":%d}\n",
      rxData.packet_id,
      rxData.temperature_c,
      rxData.humidity_pct,
      rxData.pressure_hpa,
      rxData.altitude_m,
      rxData.accel_x, rxData.accel_y, rxData.accel_z,
      rxData.gyro_x, rxData.gyro_y, rxData.gyro_z,
      rxData.pitch, rxData.roll, rxData.yaw,
      rxData.lat, rxData.lng,
      rxData.sats,
      rxData.voltage,
      rssi
    );
  }
}

void setup() {
  Serial.begin(115200);
  WiFi.mode(WIFI_STA);

  if (esp_now_init() != ESP_OK) {
    Serial.println("{\"error\":\"ESP-NOW init failed\"}");
    return;
  }

  esp_now_register_recv_cb(OnDataRecv);
  Serial.println("{\"status\":\"GS_ONLINE\",\"baud\":115200}");
}

void loop() {
  // Ground ESP32 forwards incoming packets via callback
  delay(10);
}
```

---

## 7. Troubleshooting

1. **"Web Serial API is not supported in this browser"**
   - Use Google Chrome, Microsoft Edge, or Opera on Windows, macOS, Linux, or ChromeOS.
   - Safari and Firefox do not implement Web Serial.
   - Web Serial requires a secure context (`https://` or `http://localhost`).

2. **"No valid JSON telemetry received"**
   - Verify the ESP32 is sending `\n` at the end of each line (`Serial.println` or `\n`).
   - Check baud rate is set to `115200`.
   - Open Arduino IDE Serial Monitor first to verify JSON output, then close it before clicking **CONNECT** in the browser (only one program can open a COM port at a time).
