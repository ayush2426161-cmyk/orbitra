/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import { TelemetryPacket, ConsoleLogEntry, SerialConnectionState } from '../types/telemetry';
import { playAvionicBeep, playEmergencyAlarm } from '../utils/audio';

interface TelemetryContextType {
  currentPacket: TelemetryPacket;
  history: TelemetryPacket[];
  logs: ConsoleLogEntry[];
  isConnected: boolean;
  isStreaming: boolean;
  mode: 'LIVE' | 'SIM';
  baudRate: number;
  port: string;
  emergencyKillActive: boolean;
  isCalibrating: boolean;
  alertsAcknowledged: boolean;
  packetTotalHeader: number;

  // Real Web Serial Telemetry State
  isSerialConnected: boolean;
  serialStatus: SerialConnectionState;
  lastPacketTime: string | null;
  livePacketCount: number;
  parseErrorCount: number;
  serialError: string | null;
  isWebSerialSupported: boolean;

  toggleStreaming: () => void;
  toggleConnection: () => Promise<void>;
  connectGroundStation: () => Promise<void>;
  disconnectGroundStation: () => Promise<void>;
  clearSerialError: () => void;
  setMode: (mode: 'LIVE' | 'SIM') => void;
  setBaudRate: (baud: number) => void;
  setPort: (port: string) => void;
  calibrateZero: () => void;
  ackAlerts: () => void;
  triggerEmergencyKill: () => void;
  resetEmergencyKill: () => void;
  clearBuffer: () => void;
  exportCsv: () => void;
  sendCommand: (cmd: string) => Promise<void>;
  clearLogs: () => void;
}

const initialPacket: TelemetryPacket = {
  timestamp: Date.now(),
  packetId: 1051,
  temp: 26.5,
  hum: 54.0,
  press: 1011.4,
  altAgl: 143.1,
  altMsl: 102.4,
  accel: { x: 0.03, y: -0.02, z: 9.81 },
  gyro: { x: 0.12, y: -0.05, z: 0.01 },
  orientation: { pitch: 1.4, roll: -0.8, yaw: 42.6 },
  quaternion: [0.01, -0.007, 0.363, 0.931],
  gnss: {
    lat: 26.7314,
    lng: 83.4331,
    sats: 8,
    fixType: '3D FIX',
    alt: 102.4,
    speed: 0.0,
    hdop: 0.92,
  },
  eps: {
    voltage: 3.84,
    soc: 84,
    freeHeap: 184,
    cpuTemp: 41.8,
    currentMa: 312,
  },
  link: {
    rssi: -64,
    rtt: 12,
    dropCount: 0,
    rateHz: 1.0,
  },
};

const initialLogs: ConsoleLogEntry[] = [
  {
    id: 'log-1',
    timestamp: '15:57:48Z',
    rawTime: Date.now() - 11000,
    type: 'INFO',
    message: '[BOOT] ORBITRA GS-01 Ground Terminal initialized at MMMUT Gorakhpur avionics bay.',
  },
  {
    id: 'log-2',
    timestamp: '15:57:50Z',
    rawTime: Date.now() - 9000,
    type: 'INFO',
    message: '[SERIAL] Ready for Web Serial ground station connection @ 115200 8N1.',
  },
  {
    id: 'log-3',
    timestamp: '15:57:52Z',
    rawTime: Date.now() - 7000,
    type: 'INFO',
    message: '[ESP-NOW] Waiting for ground ESP32 forwarder JSON telemetry link...',
  },
  {
    id: 'log-4',
    timestamp: '15:57:54Z',
    rawTime: Date.now() - 5000,
    type: 'RX',
    message: '{"status":"READY","baud":115200,"protocol":"ESP-NOW->JSON"}',
  },
  {
    id: 'log-5',
    timestamp: '15:57:56Z',
    rawTime: Date.now() - 3000,
    type: 'RX',
    message: '{"temperature_c":27.2,"humidity_pct":58,"pressure_hpa":1007.8}',
  },
  {
    id: 'log-6',
    timestamp: '15:57:59Z',
    rawTime: Date.now() - 1000,
    type: 'INFO',
    message: '[SYNC] Ready. Connect Ground Station to stream live telemetry directly from ESP32.',
  },
];

const TelemetryContext = createContext<TelemetryContextType | null>(null);

export function TelemetryProvider({ children }: { children: React.ReactNode }) {
  const [currentPacket, setCurrentPacket] = useState<TelemetryPacket>(initialPacket);
  const [history, setHistory] = useState<TelemetryPacket[]>([initialPacket]);
  const [logs, setLogs] = useState<ConsoleLogEntry[]>(initialLogs);
  const [isConnected, setIsConnected] = useState<boolean>(true);
  const [isStreaming, setIsStreaming] = useState<boolean>(true);
  const [mode, setMode] = useState<'LIVE' | 'SIM'>('LIVE');
  const [baudRate, setBaudRate] = useState<number>(115200);
  const [port, setPort] = useState<string>('/dev/ttyUSB0 (ESP32 GS)');
  const [emergencyKillActive, setEmergencyKillActive] = useState<boolean>(false);
  const [isCalibrating, setIsCalibrating] = useState<boolean>(false);
  const [alertsAcknowledged, setAlertsAcknowledged] = useState<boolean>(false);
  const [packetTotalHeader, setPacketTotalHeader] = useState<number>(14892);

  // Real Web Serial States
  const [isSerialConnected, setIsSerialConnected] = useState<boolean>(false);
  const [serialStatus, setSerialStatus] = useState<SerialConnectionState>('DISCONNECTED');
  const [lastPacketTime, setLastPacketTime] = useState<string | null>('15:57:56Z');
  const [livePacketCount, setLivePacketCount] = useState<number>(1);
  const [parseErrorCount, setParseErrorCount] = useState<number>(0);
  const [serialError, setSerialError] = useState<string | null>(null);

  const calibrationOffsets = useRef({ ax: 0, ay: 0, az: 0, gx: 0, gy: 0, gz: 0 });
  const serialPortRef = useRef<any>(null);
  const serialReaderRef = useRef<ReadableStreamDefaultReader<Uint8Array> | null>(null);
  const keepReadingRef = useRef<boolean>(false);
  const noPacketTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const livePacketCountRef = useRef<number>(1);

  // Sync ref
  useEffect(() => {
    livePacketCountRef.current = livePacketCount;
  }, [livePacketCount]);

  const isWebSerialSupported = typeof navigator !== 'undefined' && 'serial' in navigator;

  // Process a valid parsed JSON telemetry object without inventing missing fields
  const handleParsedTelemetryJson = useCallback((rawJson: Record<string, any>, rawLine: string) => {
    const now = Date.now();
    const timeStr = new Date(now).toISOString().substring(11, 19) + 'Z';

    // 1. Log incoming raw JSON line in console as RX
    setLogs((prev) => [
      ...prev.slice(-199),
      {
        id: `rx-${now}-${Math.random().toString(36).substring(2, 7)}`,
        timestamp: timeStr,
        rawTime: now,
        type: 'RX',
        message: rawLine,
      },
    ]);

    // 2. Clear timeout warning if it was active
    setSerialError((prev) => (prev && prev.includes('no valid JSON') ? null : prev));

    // 3. Update packet counts & time
    setLastPacketTime(timeStr);
    setLivePacketCount((c) => c + 1);
    setPacketTotalHeader((h) => h + 1);

    // 4. Update currentPacket WITHOUT inventing missing fields
    setCurrentPacket((prev) => {
      // Packet ID
      const pktId =
        typeof rawJson.packet_id === 'number'
          ? rawJson.packet_id
          : typeof rawJson.pkt_id === 'number'
          ? rawJson.pkt_id
          : typeof rawJson.packetId === 'number'
          ? rawJson.packetId
          : typeof rawJson.pkt === 'number'
          ? rawJson.pkt
          : typeof rawJson.id === 'number'
          ? rawJson.id
          : prev.packetId + 1;

      // Environmental sensors
      const tempVal =
        rawJson.temperature_c ??
        rawJson.temp_c ??
        rawJson.temperature ??
        rawJson.temp ??
        rawJson.t;
      const humVal =
        rawJson.humidity_pct ??
        rawJson.humidity ??
        rawJson.hum_pct ??
        rawJson.hum ??
        rawJson.h;
      const pressVal =
        rawJson.pressure_hpa ??
        rawJson.pressure ??
        rawJson.press_hpa ??
        rawJson.press ??
        rawJson.p;
      const altAglVal =
        rawJson.altitude_m ??
        rawJson.alt_m ??
        rawJson.altitude ??
        rawJson.alt_agl ??
        rawJson.alt;
      const altMslVal =
        rawJson.alt_msl ??
        rawJson.altMsl ??
        rawJson.gps_alt;

      const nextTemp = typeof tempVal === 'number' ? tempVal : prev.temp;
      const nextHum = typeof humVal === 'number' ? humVal : prev.hum;
      const nextPress = typeof pressVal === 'number' ? pressVal : prev.press;
      const nextAltAgl = typeof altAglVal === 'number' ? altAglVal : prev.altAgl;
      const nextAltMsl = typeof altMslVal === 'number' ? altMslVal : prev.altMsl;

      // IMU: Accel
      const accelObj = rawJson.accel as Record<string, any> | undefined;
      const ax = rawJson.accel_x ?? rawJson.ax ?? accelObj?.x;
      const ay = rawJson.accel_y ?? rawJson.ay ?? accelObj?.y;
      const az = rawJson.accel_z ?? rawJson.az ?? accelObj?.z;

      const nextAccel = {
        x: typeof ax === 'number' ? ax : prev.accel.x,
        y: typeof ay === 'number' ? ay : prev.accel.y,
        z: typeof az === 'number' ? az : prev.accel.z,
      };

      // IMU: Gyro
      const gyroObj = rawJson.gyro as Record<string, any> | undefined;
      const gx = rawJson.gyro_x ?? rawJson.gx ?? gyroObj?.x;
      const gy = rawJson.gyro_y ?? rawJson.gy ?? gyroObj?.y;
      const gz = rawJson.gyro_z ?? rawJson.gz ?? gyroObj?.z;

      const nextGyro = {
        x: typeof gx === 'number' ? gx : prev.gyro.x,
        y: typeof gy === 'number' ? gy : prev.gyro.y,
        z: typeof gz === 'number' ? gz : prev.gyro.z,
      };

      // Orientation
      const orientObj = rawJson.orientation as Record<string, any> | undefined;
      const pitch = rawJson.pitch ?? orientObj?.pitch;
      const roll = rawJson.roll ?? orientObj?.roll;
      const yaw = rawJson.yaw ?? orientObj?.yaw;

      const nextPitch = typeof pitch === 'number' ? pitch : prev.orientation.pitch;
      const nextRoll = typeof roll === 'number' ? roll : prev.orientation.roll;
      const nextYaw = typeof yaw === 'number' ? yaw : prev.orientation.yaw;

      // Quaternion: compute if pitch/roll/yaw updated, or use provided
      let nextQuat = prev.quaternion;
      if (
        Array.isArray(rawJson.quaternion) &&
        rawJson.quaternion.length === 4 &&
        rawJson.quaternion.every((v) => typeof v === 'number')
      ) {
        nextQuat = rawJson.quaternion as [number, number, number, number];
      } else if (
        typeof pitch === 'number' ||
        typeof roll === 'number' ||
        typeof yaw === 'number'
      ) {
        const c1 = Math.cos((nextPitch * Math.PI) / 360);
        const s1 = Math.sin((nextPitch * Math.PI) / 360);
        const c2 = Math.cos((nextRoll * Math.PI) / 360);
        const s2 = Math.sin((nextRoll * Math.PI) / 360);
        const c3 = Math.cos((nextYaw * Math.PI) / 360);
        const s3 = Math.sin((nextYaw * Math.PI) / 360);

        nextQuat = [
          parseFloat((s1 * c2 * c3 - c1 * s2 * s3).toFixed(4)),
          parseFloat((c1 * s2 * c3 + s1 * c2 * s3).toFixed(4)),
          parseFloat((c1 * c2 * s3 - s1 * s2 * c3).toFixed(4)),
          parseFloat((c1 * c2 * c3 + s1 * s2 * s3).toFixed(4)),
        ];
      }

      // GNSS / GPS
      const gnssObj = rawJson.gnss as Record<string, any> | undefined;
      const lat = rawJson.lat ?? rawJson.latitude ?? gnssObj?.lat;
      const lng = rawJson.lng ?? rawJson.lon ?? rawJson.longitude ?? gnssObj?.lng;
      const sats = rawJson.sats ?? rawJson.satellites ?? gnssObj?.sats;
      const speed = rawJson.speed ?? rawJson.spd ?? gnssObj?.speed;
      const fixType = rawJson.fix ?? rawJson.fixType ?? rawJson.fix_type ?? gnssObj?.fixType;
      const hdop = rawJson.hdop ?? gnssObj?.hdop;

      const nextGnss = {
        lat: typeof lat === 'number' ? lat : prev.gnss.lat,
        lng: typeof lng === 'number' ? lng : prev.gnss.lng,
        sats: typeof sats === 'number' ? sats : prev.gnss.sats,
        speed: typeof speed === 'number' ? speed : prev.gnss.speed,
        fixType: typeof fixType === 'string' ? fixType : prev.gnss.fixType,
        alt: typeof altMslVal === 'number' ? altMslVal : prev.gnss.alt,
        hdop: typeof hdop === 'number' ? hdop : prev.gnss.hdop,
      };

      // EPS / Power
      const epsObj = rawJson.eps as Record<string, any> | undefined;
      const voltage = rawJson.voltage ?? rawJson.v_bat ?? rawJson.vbat ?? epsObj?.voltage;
      const soc = rawJson.soc ?? rawJson.battery_pct ?? rawJson.bat_pct ?? epsObj?.soc;
      const freeHeap = rawJson.free_heap ?? rawJson.heap ?? epsObj?.freeHeap;
      const cpuTemp = rawJson.cpu_temp ?? rawJson.cpuTemp ?? epsObj?.cpuTemp;
      const currentMa = rawJson.current_ma ?? rawJson.currentMa ?? epsObj?.currentMa;

      const nextVoltage = typeof voltage === 'number' ? voltage : prev.eps.voltage;
      const nextSoc =
        typeof soc === 'number'
          ? soc
          : typeof voltage === 'number'
          ? Math.round(Math.min(100, Math.max(0, ((voltage - 3.4) / (4.2 - 3.4)) * 100)))
          : prev.eps.soc;

      const nextEps = {
        voltage: nextVoltage,
        soc: nextSoc,
        freeHeap: typeof freeHeap === 'number' ? freeHeap : prev.eps.freeHeap,
        cpuTemp: typeof cpuTemp === 'number' ? cpuTemp : prev.eps.cpuTemp,
        currentMa: typeof currentMa === 'number' ? currentMa : prev.eps.currentMa,
      };

      // Link
      const linkObj = rawJson.link as Record<string, any> | undefined;
      const rssi = rawJson.rssi ?? linkObj?.rssi;
      const rtt = rawJson.rtt ?? linkObj?.rtt;
      const dropCount = rawJson.drops ?? rawJson.drop_count ?? linkObj?.dropCount;

      const nextLink = {
        rssi: typeof rssi === 'number' ? rssi : prev.link.rssi,
        rtt: typeof rtt === 'number' ? rtt : prev.link.rtt,
        dropCount: typeof dropCount === 'number' ? dropCount : prev.link.dropCount,
        rateHz: 1.0,
      };

      const updatedPacket: TelemetryPacket = {
        timestamp: now,
        packetId: pktId,
        temp: nextTemp,
        hum: nextHum,
        press: nextPress,
        altAgl: nextAltAgl,
        altMsl: nextAltMsl,
        accel: nextAccel,
        gyro: nextGyro,
        orientation: {
          pitch: nextPitch,
          roll: nextRoll,
          yaw: nextYaw,
        },
        quaternion: nextQuat,
        gnss: nextGnss,
        eps: nextEps,
        link: nextLink,
      };

      // Append to history buffer for live charts auto-scrolling
      setHistory((hist) => [...hist.slice(-199), updatedPacket]);

      return updatedPacket;
    });
  }, []);

  // Web Serial Disconnect & Clean Resource Release
  const disconnectGroundStation = useCallback(async () => {
    keepReadingRef.current = false;

    if (noPacketTimeoutRef.current) {
      clearTimeout(noPacketTimeoutRef.current);
      noPacketTimeoutRef.current = null;
    }

    try {
      if (serialReaderRef.current) {
        await serialReaderRef.current.cancel().catch(() => {});
        serialReaderRef.current.releaseLock();
        serialReaderRef.current = null;
      }
      if (serialPortRef.current) {
        await serialPortRef.current.close().catch(() => {});
        serialPortRef.current = null;
      }
    } catch (err) {
      console.warn('Error during serial port cleanup:', err);
    }

    setIsSerialConnected(false);
    setSerialStatus('DISCONNECTED');
    setIsConnected(false);
    playAvionicBeep(600, 0.1, 'sawtooth');

    setLogs((prev) => [
      ...prev.slice(-199),
      {
        id: `disc-${Date.now()}`,
        timestamp: new Date().toISOString().substring(11, 19) + 'Z',
        rawTime: Date.now(),
        type: 'WARN',
        message: '[SERIAL] Disconnected from Ground Station ESP32. Port closed.',
      },
    ]);
  }, []);

  // Web Serial Connect with navigator.serial.requestPort() at 115200 baud
  const connectGroundStation = useCallback(async () => {
    if (!('serial' in navigator)) {
      const errMsg =
        'Web Serial API is not supported in this browser. Please open this dashboard in Google Chrome, Microsoft Edge, or Opera on desktop (HTTPS or localhost).';
      setSerialError(errMsg);
      setSerialStatus('ERROR');
      setLogs((prev) => [
        ...prev.slice(-199),
        {
          id: `err-${Date.now()}`,
          timestamp: new Date().toISOString().substring(11, 19) + 'Z',
          rawTime: Date.now(),
          type: 'CRIT',
          message: `[SERIAL_ERR] ${errMsg}`,
        },
      ]);
      return;
    }

    try {
      setSerialError(null);
      setSerialStatus('CONNECTING');

      // 1. Request port selection from user
      const serial = (navigator as any).serial;
      const selectedPort = await serial.requestPort();
      serialPortRef.current = selectedPort;

      // Inspect USB Info if available
      const info = selectedPort.getInfo ? selectedPort.getInfo() : {};
      const portName = info.usbVendorId
        ? `USB Serial (VID:${info.usbVendorId.toString(16).toUpperCase().padStart(4, '0')} PID:${(info.usbProductId || 0).toString(16).toUpperCase().padStart(4, '0')})`
        : '/dev/ttyUSB0 (ESP32 GS)';
      setPort(portName);

      // 2. Open selected port at 115200 baud
      await selectedPort.open({ baudRate: 115200 });

      setIsSerialConnected(true);
      setSerialStatus('CONNECTED');
      setIsConnected(true);
      setMode('LIVE'); // Real hardware linked -> switch to LIVE
      playAvionicBeep(1400, 0.08);

      setLogs((prev) => [
        ...prev.slice(-199),
        {
          id: `conn-${Date.now()}`,
          timestamp: new Date().toISOString().substring(11, 19) + 'Z',
          rawTime: Date.now(),
          type: 'INFO',
          message: `[SERIAL] Ground station port opened @ 115200 baud 8-N-1. Listening for JSON packets...`,
        },
      ]);

      // 3. Timeout check: if no valid JSON packet received in 8s, show helpful warning
      const startingPktCount = livePacketCountRef.current;
      if (noPacketTimeoutRef.current) clearTimeout(noPacketTimeoutRef.current);
      noPacketTimeoutRef.current = setTimeout(() => {
        if (keepReadingRef.current && livePacketCountRef.current === startingPktCount) {
          setSerialError(
            'Connected to serial port at 115200 baud, but no valid JSON telemetry received yet. Verify ground ESP32 is forwarding newline-delimited JSON and check ESP-NOW link.'
          );
        }
      }, 8000);

      // 4. Continuously read newline-delimited JSON
      keepReadingRef.current = true;
      const textDecoder = new TextDecoder();
      let lineBuffer = '';

      const readable = selectedPort.readable;
      if (!readable) {
        throw new Error('Port readable stream is unavailable.');
      }

      const reader = readable.getReader();
      serialReaderRef.current = reader;

      while (keepReadingRef.current) {
        const { value, done } = await reader.read();
        if (done) break;

        if (value) {
          lineBuffer += textDecoder.decode(value, { stream: true });
          const lines = lineBuffer.split(/\r?\n/);
          lineBuffer = lines.pop() || ''; // Buffer uncompleted trailing slice

          for (const rawLine of lines) {
            const trimmed = rawLine.trim();
            if (!trimmed) continue;

            // Attempt JSON parse
            try {
              const parsed = JSON.parse(trimmed);
              if (typeof parsed === 'object' && parsed !== null) {
                handleParsedTelemetryJson(parsed, trimmed);
              } else {
                throw new Error('Parsed data is not a JSON object');
              }
            } catch (pErr) {
              setParseErrorCount((c) => c + 1);
              setLogs((prev) => [
                ...prev.slice(-199),
                {
                  id: `perr-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
                  timestamp: new Date().toISOString().substring(11, 19) + 'Z',
                  rawTime: Date.now(),
                  type: 'WARN',
                  message: `[PARSE_ERR] Non-JSON line: ${trimmed.substring(0, 90)}`,
                },
              ]);
            }
          }
        }
      }
    } catch (err: any) {
      if (err.name === 'NotFoundError') {
        // User dismissed the browser port selector
        setSerialStatus(isSerialConnected ? 'CONNECTED' : 'DISCONNECTED');
        return;
      }
      console.error('Web Serial error:', err);
      setSerialError(`Serial connection failed: ${err.message || String(err)}`);
      setSerialStatus('ERROR');
      disconnectGroundStation();
    }
  }, [disconnectGroundStation, handleParsedTelemetryJson, isSerialConnected]);

  // Demo simulator interval loop: ONLY runs when mode === 'SIM'!
  useEffect(() => {
    // CRITICAL: Demo data is strictly separate from live hardware data!
    if (mode !== 'SIM' || !isStreaming || !isConnected || emergencyKillActive) {
      return;
    }

    const interval = setInterval(() => {
      setPacketTotalHeader((prev) => prev + 1);

      setCurrentPacket((prev) => {
        const nextPktId = prev.packetId + 1;
        const now = Date.now();

        // Realistic avionics physical jitter & micro-fluctuations
        const tempJitter = (Math.random() - 0.48) * 0.15;
        const humJitter = (Math.random() - 0.5) * 0.25;
        const pressJitter = (Math.random() - 0.49) * 0.15;
        const altJitter = (Math.random() - 0.5) * 0.3;

        // IMU micro dynamics
        const rawAx =
          0.03 + Math.sin(now / 2000) * 0.04 + (Math.random() - 0.5) * 0.02 - calibrationOffsets.current.ax;
        const rawAy =
          -0.02 + Math.cos(now / 2500) * 0.03 + (Math.random() - 0.5) * 0.02 - calibrationOffsets.current.ay;
        const rawAz =
          9.81 + Math.sin(now / 3500) * 0.05 + (Math.random() - 0.5) * 0.02 - calibrationOffsets.current.az;

        const rawGx = 0.12 + Math.sin(now / 1500) * 0.08 - calibrationOffsets.current.gx;
        const rawGy = -0.05 + Math.cos(now / 1800) * 0.07 - calibrationOffsets.current.gy;
        const rawGz = 0.01 + Math.sin(now / 2200) * 0.05 - calibrationOffsets.current.gz;

        // Attitude Euler integration
        const pitch = parseFloat((prev.orientation.pitch + rawGx * 0.05).toFixed(2));
        const roll = parseFloat((prev.orientation.roll + rawGy * 0.05).toFixed(2));
        const yaw = parseFloat(((prev.orientation.yaw + rawGz * 0.05 + 360) % 360).toFixed(2));

        // Quaternion approximation from Euler
        const c1 = Math.cos((pitch * Math.PI) / 360);
        const s1 = Math.sin((pitch * Math.PI) / 360);
        const c2 = Math.cos((roll * Math.PI) / 360);
        const s2 = Math.sin((roll * Math.PI) / 360);
        const c3 = Math.cos((yaw * Math.PI) / 360);
        const s3 = Math.sin((yaw * Math.PI) / 360);

        const qx = parseFloat((s1 * c2 * c3 - c1 * s2 * s3).toFixed(4));
        const qy = parseFloat((c1 * s2 * c3 + s1 * c2 * s3).toFixed(4));
        const qz = parseFloat((c1 * c2 * s3 - s1 * s2 * c3).toFixed(4));
        const qw = parseFloat((c1 * c2 * c3 + s1 * s2 * s3).toFixed(4));

        const newVoltage = parseFloat(
          Math.max(3.6, Math.min(4.15, prev.eps.voltage + (Math.random() - 0.52) * 0.005)).toFixed(2)
        );
        const soc = Math.round(Math.min(100, Math.max(10, ((newVoltage - 3.4) / (4.2 - 3.4)) * 100)));

        const newTemp = parseFloat(Math.max(18, Math.min(32, prev.temp + tempJitter)).toFixed(1));
        const newHum = parseFloat(Math.max(40, Math.min(75, prev.hum + humJitter)).toFixed(1));
        const newPress = parseFloat(Math.max(990, Math.min(1030, prev.press + pressJitter)).toFixed(1));
        const newAltAgl = parseFloat(Math.max(130, Math.min(160, prev.altAgl + altJitter)).toFixed(1));

        const newPacket: TelemetryPacket = {
          timestamp: now,
          packetId: nextPktId,
          temp: newTemp,
          hum: newHum,
          press: newPress,
          altAgl: newAltAgl,
          altMsl: 102.4,
          accel: {
            x: parseFloat(rawAx.toFixed(2)),
            y: parseFloat(rawAy.toFixed(2)),
            z: parseFloat(rawAz.toFixed(2)),
          },
          gyro: {
            x: parseFloat(rawGx.toFixed(2)),
            y: parseFloat(rawGy.toFixed(2)),
            z: parseFloat(rawGz.toFixed(2)),
          },
          orientation: { pitch, roll, yaw },
          quaternion: [qx, qy, qz, qw],
          gnss: {
            lat: 26.7314,
            lng: 83.4331,
            sats: 8,
            fixType: '3D FIX (8 SATS)',
            alt: 102.4,
            speed: 0.0,
            hdop: 0.92,
          },
          eps: {
            voltage: newVoltage,
            soc,
            freeHeap: Math.round(184 + Math.sin(now / 10000) * 4),
            cpuTemp: parseFloat((41.8 + Math.sin(now / 8000) * 0.4).toFixed(1)),
            currentMa: Math.round(310 + Math.random() * 8),
          },
          link: {
            rssi: Math.round(-64 + (Math.random() - 0.5) * 4),
            rtt: Math.round(12 + Math.random() * 2),
            dropCount: prev.link.dropCount,
            rateHz: 1.0,
          },
        };

        setHistory((hist) => [...hist.slice(-199), newPacket]);

        if (nextPktId % 3 === 0) {
          const timeStr = new Date(now).toISOString().substring(11, 19) + 'Z';
          const telMsg = `{"temperature_c":${newTemp},"humidity_pct":${newHum},"pressure_hpa":${newPress}}`;
          setLogs((lg) => [
            ...lg.slice(-99),
            {
              id: `log-${nextPktId}`,
              timestamp: timeStr,
              rawTime: now,
              type: 'RX',
              message: telMsg,
            },
          ]);
        }

        return newPacket;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [mode, isStreaming, isConnected, emergencyKillActive]);

  const toggleStreaming = useCallback(() => {
    setIsStreaming((prev) => {
      const next = !prev;
      playAvionicBeep(next ? 1500 : 700, 0.05);
      return next;
    });
  }, []);

  const toggleConnection = useCallback(async () => {
    if (isSerialConnected) {
      await disconnectGroundStation();
    } else if (mode === 'LIVE') {
      await connectGroundStation();
    } else {
      // Toggle simulated link
      setIsConnected((prev) => {
        const next = !prev;
        playAvionicBeep(next ? 1400 : 600, 0.08);
        setLogs((l) => [
          ...l.slice(-99),
          {
            id: `sim-conn-${Date.now()}`,
            timestamp: new Date().toISOString().substring(11, 19) + 'Z',
            rawTime: Date.now(),
            type: next ? 'INFO' : 'WARN',
            message: next ? '[SIM] Simulated link re-established.' : '[SIM] Simulated link paused.',
          },
        ]);
        return next;
      });
    }
  }, [isSerialConnected, mode, disconnectGroundStation, connectGroundStation]);

  const clearSerialError = useCallback(() => {
    setSerialError(null);
  }, []);

  const calibrateZero = useCallback(() => {
    setIsCalibrating(true);
    playAvionicBeep(1800, 0.08);
    setTimeout(() => {
      calibrationOffsets.current = {
        ax: currentPacket.accel.x,
        ay: currentPacket.accel.y,
        az: currentPacket.accel.z - 9.81,
        gx: currentPacket.gyro.x,
        gy: currentPacket.gyro.y,
        gz: currentPacket.gyro.z,
      };
      setIsCalibrating(false);
      playAvionicBeep(2200, 0.06);
      setLogs((prev) => [
        ...prev.slice(-99),
        {
          id: `cal-${Date.now()}`,
          timestamp: new Date().toISOString().substring(11, 19) + 'Z',
          rawTime: Date.now(),
          type: 'INFO',
          message: '[CAL] MPU6050 6-DOF zero calibration matrix stored in volatile flash.',
        },
      ]);
    }, 600);
  }, [currentPacket]);

  const ackAlerts = useCallback(() => {
    setAlertsAcknowledged(true);
    playAvionicBeep(1100, 0.04);
    setTimeout(() => setAlertsAcknowledged(false), 2000);
  }, []);

  const triggerEmergencyKill = useCallback(() => {
    setEmergencyKillActive(true);
    playEmergencyAlarm();
    setLogs((prev) => [
      ...prev.slice(-99),
      {
        id: `kill-${Date.now()}`,
        timestamp: new Date().toISOString().substring(11, 19) + 'Z',
        rawTime: Date.now(),
        type: 'CRIT',
        message: '!!! [EMERGENCY RF KILL] Spacecraft transmitter power stage cut off. Command uplink disabled.',
      },
    ]);
  }, []);

  const resetEmergencyKill = useCallback(() => {
    setEmergencyKillActive(false);
    playAvionicBeep(1200, 0.05);
    setLogs((prev) => [
      ...prev.slice(-99),
      {
        id: `unkill-${Date.now()}`,
        timestamp: new Date().toISOString().substring(11, 19) + 'Z',
        rawTime: Date.now(),
        type: 'INFO',
        message: '[RESTORE] Emergency RF Kill interlock disengaged. Normal avionics loop re-armed.',
      },
    ]);
  }, []);

  const clearBuffer = useCallback(() => {
    setHistory([]);
    setCurrentPacket((p) => ({ ...p, packetId: 0 }));
    playAvionicBeep(800, 0.05);
  }, []);

  const exportCsv = useCallback(() => {
    playAvionicBeep(1600, 0.05);
    const headers =
      'Timestamp,PacketID,Temp_C,Hum_Pct,Press_hPa,Alt_AGL_m,Alt_MSL_m,AccelX,AccelY,AccelZ,GyroX,GyroY,GyroZ,BusVoltage_V,Battery_Pct,RSSI_dBm\n';
    const rows = history
      .map(
        (p) =>
          `${new Date(p.timestamp).toISOString()},${p.packetId},${p.temp},${p.hum},${p.press},${p.altAgl},${p.altMsl},${p.accel.x},${p.accel.y},${p.accel.z},${p.gyro.x},${p.gyro.y},${p.gyro.z},${p.eps.voltage},${p.eps.soc},${p.link.rssi}`
      )
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ORBITRA_COSMIC1_TELEMETRY_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }, [history]);

  const sendCommand = useCallback(
    async (cmd: string) => {
      const timeStr = new Date().toISOString().substring(11, 19) + 'Z';
      playAvionicBeep(1900, 0.05);

      setLogs((prev) => [
        ...prev.slice(-99),
        {
          id: `tx-${Date.now()}`,
          timestamp: timeStr,
          rawTime: Date.now(),
          type: 'TX',
          message: `> TX CMD: ${cmd.toUpperCase()}`,
          hex: Array.from(cmd)
            .map((c) => c.charCodeAt(0).toString(16).toUpperCase().padStart(2, '0'))
            .join(' '),
        },
      ]);

      // If Web Serial port is open and writable, forward command over USB Serial
      if (serialPortRef.current && serialPortRef.current.writable) {
        try {
          const encoder = new TextEncoder();
          const writer = serialPortRef.current.writable.getWriter();
          await writer.write(encoder.encode(cmd + '\n'));
          writer.releaseLock();
        } catch (wErr) {
          console.warn('Error sending command over Web Serial:', wErr);
        }
      }

      // Simulated satellite response if in SIM mode
      if (mode === 'SIM') {
        setTimeout(() => {
          let response = `[ACK] Command '${cmd}' accepted by COSMIC-1 OBC.`;
          const upper = cmd.trim().toUpperCase();
          if (upper === 'PING') response = '{"cmd_ack":"PING","rtt_ms":11.8,"rssi_dbm":-63}';
          else if (upper.startsWith('CAL_IMU')) response = '{"cmd_ack":"CAL_IMU","status":"OK","offsets":{"ax":0.03,"ay":-0.02,"az":9.81}}';
          else if (upper.startsWith('SET_TX_PWR')) response = `{"cmd_ack":"SET_TX_PWR","pwr":"${upper.split(' ')[1] || '20dBm'}"}`;
          else if (upper === 'SYS_DIAG') response = '{"cmd_ack":"SYS_DIAG","cpu_c":41.8,"heap_kb":184,"vbus_v":3.84}';
          else if (upper === 'SAFE_MODE') response = '*** [ALERT] COSMIC-1 entered ATTITUDE_SAFE_HOLD mode ***';

          setLogs((prev) => [
            ...prev.slice(-99),
            {
              id: `ack-${Date.now()}`,
              timestamp: new Date().toISOString().substring(11, 19) + 'Z',
              rawTime: Date.now(),
              type: upper === 'SAFE_MODE' ? 'WARN' : 'RX',
              message: response,
            },
          ]);
        }, 280);
      }
    },
    [mode]
  );

  const clearLogs = useCallback(() => {
    setLogs([]);
  }, []);

  return (
    <TelemetryContext.Provider
      value={{
        currentPacket,
        history,
        logs,
        isConnected,
        isStreaming,
        mode,
        baudRate,
        port,
        emergencyKillActive,
        isCalibrating,
        alertsAcknowledged,
        packetTotalHeader,
        isSerialConnected,
        serialStatus,
        lastPacketTime,
        livePacketCount,
        parseErrorCount,
        serialError,
        isWebSerialSupported,
        toggleStreaming,
        toggleConnection,
        connectGroundStation,
        disconnectGroundStation,
        clearSerialError,
        setMode,
        setBaudRate,
        setPort,
        calibrateZero,
        ackAlerts,
        triggerEmergencyKill,
        resetEmergencyKill,
        clearBuffer,
        exportCsv,
        sendCommand,
        clearLogs,
      }}
    >
      {children}
    </TelemetryContext.Provider>
  );
}

export function useTelemetry() {
  const context = useContext(TelemetryContext);
  if (!context) {
    throw new Error('useTelemetry must be used within a TelemetryProvider');
  }
  return context;
}
