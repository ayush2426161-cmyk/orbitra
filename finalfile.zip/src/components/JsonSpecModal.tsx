/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';

interface JsonSpecModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function JsonSpecModal({ isOpen, onClose }: JsonSpecModalProps) {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const sampleMinimal = `{"temperature_c":27.2,"humidity_pct":58,"pressure_hpa":1007.8}`;

  const sampleFull = `{
  "packet_id": 1052,
  "temperature_c": 26.5,
  "humidity_pct": 54.0,
  "pressure_hpa": 1011.4,
  "altitude_m": 143.1,
  "accel_x": 0.03,
  "accel_y": -0.02,
  "accel_z": 9.81,
  "gyro_x": 0.12,
  "gyro_y": -0.05,
  "gyro_z": 0.01,
  "pitch": 1.4,
  "roll": -0.8,
  "yaw": 42.6,
  "lat": 26.7314,
  "lng": 83.4331,
  "sats": 8,
  "voltage": 3.84,
  "rssi": -64
}`;

  const arduinoSnippet = `// Ground-Station ESP32 (Receives ESP-NOW & forwards JSON over USB Serial)
#include <esp_now.h>
#include <WiFi.h>

void OnDataRecv(const esp_now_recv_info_t *info, const uint8_t *data, int len) {
  // Option A: Forward pre-formatted JSON string directly
  // Serial.println((char*)data);

  // Option B: Format struct fields into newline-delimited JSON
  Serial.printf("{\\"temperature_c\\":%.2f,\\"humidity_pct\\":%.1f,\\"pressure_hpa\\":%.2f}\\n",
    27.2, 58.0, 1007.8
  );
}

void setup() {
  Serial.begin(115200);
  WiFi.mode(WIFI_STA);
  esp_now_init();
  esp_now_register_recv_cb(OnDataRecv);
}

void loop() { delay(10); }`;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-[#111A2B] border border-[#1E2A3F] rounded-xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#1E2A3F]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#0A1020] border border-[#1E2A3F] flex items-center justify-center text-[#22D3EE]">
              <span className="material-symbols-outlined text-[18px]">data_object</span>
            </div>
            <div>
              <h3 className="font-sans text-sm font-bold text-white uppercase tracking-wider">
                Ground ESP32 JSON Telemetry Specification
              </h3>
              <p className="font-mono text-[10px] text-[#8B9BB4]">
                115200 Baud • Newline-Delimited JSON (`\n`) • Web Serial Compatible
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-[#0A1020] hover:bg-[#1E2A3F] text-[#8B9BB4] hover:text-white flex items-center justify-center border border-[#1E2A3F] transition-colors"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4 font-mono text-xs">
          {/* Note about missing fields */}
          <div className="bg-[#22D3EE]/10 border border-[#22D3EE]/30 rounded-lg p-3 text-[#22D3EE] text-[11px] leading-relaxed">
            <strong className="block font-semibold">Strict Field Integrity Rule:</strong>
            The dashboard updates instruments only for fields provided in incoming JSON. Missing fields retain their last known values and will <em>never</em> be filled with synthetic random jitter.
          </div>

          {/* Minimal Packet */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-white font-bold text-[11px] uppercase tracking-wider">
                1. Minimal Supported Packet (Sample)
              </span>
              <button
                onClick={() => copyToClipboard(sampleMinimal, 'min')}
                className="text-[10px] text-[#22D3EE] hover:underline"
              >
                {copiedKey === 'min' ? 'COPIED!' : 'COPY JSON'}
              </button>
            </div>
            <pre className="bg-[#050811] border border-[#1E2A3F] rounded-lg p-3 text-[#34D399] overflow-x-auto text-[11px]">
              {sampleMinimal}
            </pre>
          </div>

          {/* Expected Field Names Table */}
          <div>
            <span className="text-white font-bold text-[11px] uppercase tracking-wider block mb-1.5">
              2. Supported JSON Keys & Aliases
            </span>
            <div className="border border-[#1E2A3F] rounded-lg overflow-hidden">
              <table className="w-full text-left text-[10px]">
                <thead className="bg-[#0A1020] text-[#8B9BB4] border-b border-[#1E2A3F]">
                  <tr>
                    <th className="p-2">Target Sensor</th>
                    <th className="p-2">Primary Key</th>
                    <th className="p-2">Recognized Aliases</th>
                    <th className="p-2">Unit</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1E2A3F] text-[#8B9BB4]">
                  <tr className="hover:bg-[#0A1020]/50">
                    <td className="p-2 text-white">Temperature</td>
                    <td className="p-2 text-[#22D3EE]">temperature_c</td>
                    <td className="p-2">temp_c, temperature, temp, t</td>
                    <td className="p-2">°C</td>
                  </tr>
                  <tr className="hover:bg-[#0A1020]/50">
                    <td className="p-2 text-white">Humidity</td>
                    <td className="p-2 text-[#22D3EE]">humidity_pct</td>
                    <td className="p-2">humidity, hum_pct, hum, h</td>
                    <td className="p-2">% RH</td>
                  </tr>
                  <tr className="hover:bg-[#0A1020]/50">
                    <td className="p-2 text-white">Pressure</td>
                    <td className="p-2 text-[#A78BFA]">pressure_hpa</td>
                    <td className="p-2">pressure, press_hpa, press, p</td>
                    <td className="p-2">hPa</td>
                  </tr>
                  <tr className="hover:bg-[#0A1020]/50">
                    <td className="p-2 text-white">Altitude (AGL)</td>
                    <td className="p-2 text-[#34D399]">altitude_m</td>
                    <td className="p-2">alt_m, altitude, alt_agl, alt</td>
                    <td className="p-2">m</td>
                  </tr>
                  <tr className="hover:bg-[#0A1020]/50">
                    <td className="p-2 text-white">Acceleration (XYZ)</td>
                    <td className="p-2 text-white">accel_x, accel_y, accel_z</td>
                    <td className="p-2">ax, ay, az or accel: {`{x,y,z}`}</td>
                    <td className="p-2">m/s²</td>
                  </tr>
                  <tr className="hover:bg-[#0A1020]/50">
                    <td className="p-2 text-white">Gyroscope (XYZ)</td>
                    <td className="p-2 text-white">gyro_x, gyro_y, gyro_z</td>
                    <td className="p-2">gx, gy, gz or gyro: {`{x,y,z}`}</td>
                    <td className="p-2">°/s</td>
                  </tr>
                  <tr className="hover:bg-[#0A1020]/50">
                    <td className="p-2 text-white">Attitude (Euler)</td>
                    <td className="p-2 text-white">pitch, roll, yaw</td>
                    <td className="p-2">orientation: {`{pitch,roll,yaw}`}</td>
                    <td className="p-2">deg</td>
                  </tr>
                  <tr className="hover:bg-[#0A1020]/50">
                    <td className="p-2 text-white">GPS Coordinates</td>
                    <td className="p-2 text-white">lat, lng, sats</td>
                    <td className="p-2">latitude, lon, longitude, satellites</td>
                    <td className="p-2">deg, count</td>
                  </tr>
                  <tr className="hover:bg-[#0A1020]/50">
                    <td className="p-2 text-white">Battery / EPS</td>
                    <td className="p-2 text-white">voltage, soc</td>
                    <td className="p-2">v_bat, vbat, battery_pct</td>
                    <td className="p-2">V, %</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Full JSON Example */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-white font-bold text-[11px] uppercase tracking-wider">
                3. Full Telemetry Object Example
              </span>
              <button
                onClick={() => copyToClipboard(sampleFull, 'full')}
                className="text-[10px] text-[#22D3EE] hover:underline"
              >
                {copiedKey === 'full' ? 'COPIED!' : 'COPY FULL JSON'}
              </button>
            </div>
            <pre className="bg-[#050811] border border-[#1E2A3F] rounded-lg p-3 text-[#22D3EE] overflow-x-auto text-[10px] max-h-48">
              {sampleFull}
            </pre>
          </div>

          {/* Arduino Code Snippet */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-white font-bold text-[11px] uppercase tracking-wider">
                4. Ground ESP32 Firmware Snippet (Arduino C++)
              </span>
              <button
                onClick={() => copyToClipboard(arduinoSnippet, 'ino')}
                className="text-[10px] text-[#22D3EE] hover:underline"
              >
                {copiedKey === 'ino' ? 'COPIED!' : 'COPY C++ CODE'}
              </button>
            </div>
            <pre className="bg-[#050811] border border-[#1E2A3F] rounded-lg p-3 text-[#8B9BB4] overflow-x-auto text-[10px] max-h-48">
              {arduinoSnippet}
            </pre>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[#1E2A3F] flex items-center justify-between bg-[#0A1020]">
          <span className="text-[10px] text-[#8B9BB4] font-mono">
            Specification file also saved at <code className="text-[#22D3EE]">/public/ESP32_TELEMETRY_SPEC.md</code>
          </span>
          <button
            onClick={onClose}
            className="bg-[#22D3EE] hover:bg-[#06B6D4] text-[#0A1020] font-mono text-[11px] font-bold px-4 py-1.5 rounded-lg transition-all"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
}
